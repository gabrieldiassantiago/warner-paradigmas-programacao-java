/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Gerente extends Pessoa {
    
    public Gerente(int id, String senha) {
        super(id, senha);
    }
    
    public void finalizarSistema() {
        System.out.println("Sistema finalizado");
    }
    
    public void iniciarSistema() {
        System.out.println("Sistema iniciado");
    }
    
    
    
    
    
    
    
    
}
