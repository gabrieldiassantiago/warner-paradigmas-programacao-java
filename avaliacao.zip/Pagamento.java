/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Pagamento {
    
    public void pagarDinheiro(double valor, double valorPago) {
                
       if (valorPago >= valor) { //erro estaava aqui
           double troco = valorPago - valor;
           System.out.println("O valor do troco é: " + troco);
       }
       
    }
    
    public void pagarCartao() {
        System.out.println("Venda realizada com cartão de credito");
    }
    
    
    
}
