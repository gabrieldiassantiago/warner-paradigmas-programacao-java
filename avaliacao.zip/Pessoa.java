/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Pessoa {

    private int id;
    private String senha;
    
    public Pessoa(int id, String senha) {
        this.id = id;
        this.senha = senha;
    }
    
    public void login(int id, String senha) {
        if (senha.equals(this.senha) && id == this.id) {
            System.out.println("Login efetuado com sucesso com o id: " + id + " e senha: " + senha);
        } else {
            System.out.println("Login falhou. Id ou senha incorretos.");
        }

        /* aqui ele compara realmente o login recebido do param com o registro real,
        coisa que esquecemos de fazer :(

         */

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
    
}
