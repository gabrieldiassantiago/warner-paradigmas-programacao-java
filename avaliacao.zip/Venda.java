/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Venda {
    
    Produto[] produtos = new Produto[10];
    
    public Venda() {
        
    }
    
    int qtd = 0;
    
    public void adicionarProduto(Produto p) {
        produtos[qtd] = p;
        qtd++;
        p.mostraProduto();
    }
    
    public double calcularTotal() {
        
        double total = 0;

        /*
        No metodo calcularTotal, a gente fez o mod "for-each" (for (Produto produto : produtos)).
        Esse tipo de loop vaipercorre as 10 posições do array. Se a gente
        adicionou apenas 2 produtos, ele vai tentar pegar o preço das outras 8 posições vazias e o
        programa vai travar.
         */


        for (int i = 0; i < qtd; i++) {
            total += produtos[i].getPreco();
        }

        return total;
    
    }

    public void finalizarVenda() {
        System.out.println("\n--- ATUALIZANDO ESTOQUE ---");

        for (int i = 0; i < qtd; i++) {
            // Rduz o estoque do produto
            produtos[i].diminuiEstoqueProduto();

            // exibe o novo estado do produto após a redução
            System.out.println("Produto: " + produtos[i].getNome() +
                    " | Estoque Atual: " + produtos[i].getEstoque());
        }

        System.out.println("---------------------------");
        System.out.println("VENDA FINALIZADA: Registrada no sistema com sucesso!");
    }



}
