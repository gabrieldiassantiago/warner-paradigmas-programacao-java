/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Produto {
    private String nome;
    private double preco;
    private int estoque;
    
    

    public String getNome() {
        return nome;
    }
    
    public void mostraProduto() {
        System.out.println("Nome do produto: " + this.nome + "\n" + "preço do produto: " + this.preco);
    }
    
    public void diminuiEstoqueProduto() {
        this.estoque--;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }
    
    
}
