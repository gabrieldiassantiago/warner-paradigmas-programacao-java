/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Operador extends Pessoa {
    
    public Operador(int id, String senha) {
        super(id, senha);
    }
    
    public void registrarVenda() {
        System.out.println("Venda registrada");
    }
    
    public void finalizarVenda(Venda venda) {
        venda.finalizarVenda();
    }
   
    
}
