/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio1;

/**
 *
 * @author aluno9
 */
public class Exercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


       Gerente gerente1 = new Gerente(1, "123");
       gerente1.login(1, "123");

       gerente1.iniciarSistema();

       Operador op1 = new Operador(2, "1234");
       op1.login(2, "1234");
       
       Produto p1 = new Produto();
       
       p1.setNome("Coca cola");
       p1.setEstoque(2);
       p1.setPreco(10);

       Produto p2 = new Produto();
       p2.setNome("Café");
       p2.setEstoque(6);
       p2.setPreco(50);

       Venda venda1 = new Venda();
       
       venda1.adicionarProduto(p1);
       
       venda1.adicionarProduto(p2);

       double total = venda1.calcularTotal();

       System.out.println("O total da venda eh:" + total);

       Pagamento pg = new  Pagamento();

       pg.pagarDinheiro(total, 200.0);

       venda1.finalizarVenda();

       gerente1.finalizarSistema();
       
       
    }
    
}
